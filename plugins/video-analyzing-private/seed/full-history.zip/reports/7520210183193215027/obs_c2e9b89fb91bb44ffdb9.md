# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7520210183193215027`
- Content Pattern：`V03`
- Commercial Pattern：待验证型->高消耗低效型
- Observation：`obs_c2e9b89fb91bb44ffdb9`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | mild |
| daily_orders | positive | within | neutral | within |
| ctr | positive | below | negative | mild |
| cvr | positive | within | neutral | within |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | within | neutral | within |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | medium |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 1 | 1 | 0 | within |
| Conversion | 1 | 1 | 0 | within |
| Efficiency | 1 | 1 | 0 | within |
| Scale | 1 | 5 | 4 | positive |
| Quality | 0 | 5 | 5 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_316915ffbc06c86d`：`accumulating`；有效Observation 1条
