# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7520210183193215027`
- Content Pattern：`V05`
- Commercial Pattern：低效型->规模爆款型
- Observation：`obs_c09ffbd47514cecff3bb`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | below | negative | mild |
| cvr | positive | below | negative | severe |
| settle_roi | positive | below | negative | severe |
| settle_cpo | positive | above | negative | severe |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | severe |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 1 | 1 | 0 | within |
| Conversion | 1 | 1 | 0 | within |
| Efficiency | 1 | 5 | 4 | positive |
| Scale | 1 | 5 | 4 | positive |
| Quality | 0 | 5 | 5 | positive |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_3b39589ceb9c07c5`：`accumulating`；有效Observation 1条
