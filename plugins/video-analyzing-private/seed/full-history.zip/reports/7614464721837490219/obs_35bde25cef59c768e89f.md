# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7614464721837490219`
- Content Pattern：`V01`
- Commercial Pattern：高效潜力型->强转化型
- Observation：`obs_35bde25cef59c768e89f`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | mild |
| daily_orders | positive | above | positive | medium |
| ctr | positive | below | negative | severe |
| cvr | positive | above | positive | severe |
| settle_roi | positive | below | negative | mild |
| settle_cpo | positive | within | neutral | within |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | medium |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 2 | 1 | -1 | negative |
| Conversion | 3 | 5 | 2 | positive |
| Efficiency | 5 | 3 | -2 | within |
| Scale | 3 | 5 | 2 | positive |
| Quality | 5 | 5 | 0 | within |

## 六、建议与沉淀

- 建议代码：OPTIMIZE_ATTRACTION, CALIBRATE_POSITIVE_INTERVAL
- 样本池动作：`add_as_negative_outlier`
- Cluster `cluster_96f89353cab028d3`：`accumulating`；有效Observation 1条
- Cluster `cluster_f9d46ef36ac154d1`：`accumulating`；有效Observation 1条
