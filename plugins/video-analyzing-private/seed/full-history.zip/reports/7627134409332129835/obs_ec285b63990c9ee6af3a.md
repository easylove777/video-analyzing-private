# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7627134409332129835`
- Content Pattern：`V04`
- Commercial Pattern：规模爆款型->强引流型
- Observation：`obs_ec285b63990c9ee6af3a`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | above | positive | mild |
| cvr | positive | below | negative | severe |
| settle_roi | positive | below | negative | severe |
| settle_cpo | positive | above | negative | medium |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | severe |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 2 | 4 | 2 | within |
| Conversion | 1 | 2 | 1 | within |
| Efficiency | 5 | 2 | -3 | within |
| Scale | 5 | 5 | 0 | within |
| Quality | 5 | 4 | -1 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_de69097704434d99`：`accumulating`；有效Observation 2条
