# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7624073456843259946`
- Content Pattern：`V02`
- Commercial Pattern：规模爆款型->普通型
- Observation：`obs_8aa3fc2dcddbaad99b2f`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | within | neutral | within |
| daily_gmv | positive | within | neutral | within |
| daily_orders | positive | within | neutral | within |
| ctr | positive | within | neutral | within |
| cvr | positive | below | negative | severe |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | within | neutral | within |
| refund_rate | zero | not_applicable | neutral | not_applicable |
| settle_rate | positive | within | neutral | within |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 3 | 2 | -1 | within |
| Conversion | 4 | 3 | -1 | negative |
| Efficiency | 5 | 3 | -2 | negative |
| Scale | 5 | 5 | 0 | within |
| Quality | 5 | 5 | 0 | within |

## 六、建议与沉淀

- 建议代码：OPTIMIZE_CONVERSION, OPTIMIZE_EFFICIENCY, CALIBRATE_POSITIVE_INTERVAL
- 样本池动作：`add_as_negative_outlier`
- Cluster `cluster_03dcefcefcd92262`：`accumulating`；有效Observation 1条
- Cluster `cluster_ee46216c07fdda1f`：`accumulating`；有效Observation 1条
- Cluster `cluster_3f1ac7c256fa0db8`：`accumulating`；有效Observation 1条
