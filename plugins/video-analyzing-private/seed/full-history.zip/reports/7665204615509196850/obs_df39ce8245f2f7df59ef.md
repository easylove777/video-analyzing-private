# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7665204615509196850`
- Content Pattern：`V04`
- Commercial Pattern：低效型->规模爆款型
- Observation：`obs_df39ce8245f2f7df59ef`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | mild |
| daily_orders | positive | above | positive | medium |
| ctr | positive | below | negative | medium |
| cvr | positive | within | neutral | within |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | within | neutral | within |
| refund_rate | zero | not_applicable | neutral | not_applicable |
| settle_rate | positive | within | neutral | within |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 2 | 1 | -1 | within |
| Conversion | 1 | 4 | 3 | positive |
| Efficiency | 1 | 4 | 3 | positive |
| Scale | 1 | 5 | 4 | positive |
| Quality | 0 | 5 | 5 | positive |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_57a00882e4b14052`：`accumulating`；有效Observation 1条
