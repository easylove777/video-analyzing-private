# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7576585836718505990`
- Content Pattern：`V07`
- Commercial Pattern：规模爆款型->规模爆款型
- Observation：`obs_ebc50eb831ca3a5e5792`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | within | neutral | within |
| cvr | positive | above | positive | medium |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | below | positive | mild |
| refund_rate | positive | above | negative | mild |
| settle_rate | positive | below | negative | mild |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 1 | 2 | 1 | within |
| Conversion | 1 | 4 | 3 | positive |
| Efficiency | 1 | 4 | 3 | within |
| Scale | 3 | 5 | 2 | within |
| Quality | 0 | 5 | 5 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_ffab626df778597a`：`accumulating`；有效Observation 1条
