# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7654951090635456539`
- Content Pattern：`V04`
- Commercial Pattern：规模爆款型->稳定经营型
- Observation：`obs_7fc6d6e3a6edcddf1361`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | within | neutral | within |
| cvr | positive | within | neutral | within |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | within | neutral | within |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | severe |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 3 | 3 | 0 | within |
| Conversion | 2 | 3 | 1 | within |
| Efficiency | 5 | 3 | -2 | within |
| Scale | 3 | 5 | 2 | within |
| Quality | 5 | 5 | 0 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_b453bd50568b9c97`：`accumulating`；有效Observation 2条
