# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7527585916681142323`
- Content Pattern：`V08`
- Commercial Pattern：规模爆款型->强引流型
- Observation：`obs_89fca28e9efcb935704e`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | medium |
| daily_gmv | positive | above | positive | medium |
| daily_orders | positive | above | positive | severe |
| ctr | positive | within | neutral | within |
| cvr | positive | within | neutral | within |
| settle_roi | positive | below | negative | medium |
| settle_cpo | positive | within | neutral | within |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | severe |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 3 | 4 | 1 | within |
| Conversion | 2 | 2 | 0 | within |
| Efficiency | 5 | 1 | -4 | within |
| Scale | 5 | 5 | 0 | within |
| Quality | 5 | 4 | -1 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_b5c699b60cb30180`：`accumulating`；有效Observation 1条
