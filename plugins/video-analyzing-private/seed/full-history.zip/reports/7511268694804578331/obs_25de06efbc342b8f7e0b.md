# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7511268694804578331`
- Content Pattern：`V02`
- Commercial Pattern：规模爆款型->高消耗低效型
- Observation：`obs_25de06efbc342b8f7e0b`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | medium |
| daily_orders | positive | above | positive | medium |
| ctr | positive | within | neutral | within |
| cvr | positive | below | negative | severe |
| settle_roi | positive | below | negative | medium |
| settle_cpo | positive | above | negative | severe |
| refund_rate | positive | above | negative | mild |
| settle_rate | positive | below | negative | mild |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 1 | 2 | 1 | within |
| Conversion | 4 | 2 | -2 | within |
| Efficiency | 5 | 1 | -4 | within |
| Scale | 5 | 5 | 0 | within |
| Quality | 5 | 5 | 0 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_89fa27c430ad3486`：`accumulating`；有效Observation 1条
