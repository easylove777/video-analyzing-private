# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7625596942614970387`
- Content Pattern：`V04`
- Commercial Pattern：规模爆款型->普通型
- Observation：`obs_edcded2ea922297e27b2`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | below | negative | medium |
| cvr | positive | within | neutral | within |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | within | neutral | within |
| refund_rate | zero | not_applicable | neutral | not_applicable |
| settle_rate | positive | within | neutral | within |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 3 | 1 | -2 | negative |
| Conversion | 2 | 2 | 0 | within |
| Efficiency | 5 | 3 | -2 | within |
| Scale | 5 | 5 | 0 | within |
| Quality | 5 | 5 | 0 | within |

## 六、建议与沉淀

- 建议代码：OPTIMIZE_ATTRACTION, CALIBRATE_POSITIVE_INTERVAL
- 样本池动作：`add_as_negative_outlier`
- Cluster `cluster_90e80938f499c044`：`accumulating`；有效Observation 1条
- Cluster `cluster_08a17a7b6aa30f5f`：`accumulating`；有效Observation 1条
