# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7556269205471395867`
- Content Pattern：`V04`
- Commercial Pattern：低效型->规模爆款型
- Observation：`obs_f3f3a1aaa7cb9897e1b7`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | medium |
| daily_orders | positive | above | positive | medium |
| ctr | positive | within | neutral | within |
| cvr | positive | above | positive | mild |
| settle_roi | positive | within | neutral | within |
| settle_cpo | positive | within | neutral | within |
| refund_rate | positive | above | negative | mild |
| settle_rate | positive | below | negative | mild |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 2 | 1 | -1 | within |
| Conversion | 1 | 4 | 3 | positive |
| Efficiency | 1 | 4 | 3 | within |
| Scale | 1 | 5 | 4 | positive |
| Quality | 0 | 5 | 5 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_7abcd2cf8fd2e715`：`accumulating`；有效Observation 1条
