# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7595943772032630790`
- Content Pattern：`V01`
- Commercial Pattern：规模爆款型->普通型
- Observation：`obs_c76dadfdf27d33a1c8b3`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | within | neutral | within |
| cvr | positive | above | positive | severe |
| settle_roi | positive | above | positive | mild |
| settle_cpo | positive | below | positive | mild |
| refund_rate | positive | above | negative | severe |
| settle_rate | positive | below | negative | severe |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 1 | 2 | 1 | within |
| Conversion | 1 | 2 | 1 | positive |
| Efficiency | 5 | 3 | -2 | within |
| Scale | 5 | 5 | 0 | within |
| Quality | 5 | 5 | 0 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_35dcdf5a2ce233aa`：`accumulating`；有效Observation 1条
