# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7591502364366110729`
- Content Pattern：`V04`
- Commercial Pattern：规模爆款型->高消耗低效型
- Observation：`obs_b0fb28aa6f90f875db3f`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | above | positive | severe |
| daily_orders | positive | above | positive | severe |
| ctr | positive | below | negative | mild |
| cvr | positive | below | negative | mild |
| settle_roi | positive | below | negative | medium |
| settle_cpo | positive | above | negative | severe |
| refund_rate | zero | not_applicable | neutral | not_applicable |
| settle_rate | positive | within | neutral | within |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 3 | 2 | -1 | within |
| Conversion | 3 | 1 | -2 | within |
| Efficiency | 1 | 1 | 0 | within |
| Scale | 4 | 4 | 0 | within |
| Quality | 1 | 5 | 4 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_d1c3eae7e3ff7f61`：`proposed`；有效Observation 5条
