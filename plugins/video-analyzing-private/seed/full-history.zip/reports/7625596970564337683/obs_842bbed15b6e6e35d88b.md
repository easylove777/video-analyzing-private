# 茶叶视频T+7预测分析复盘

## 一、复盘结论

- 素材ID：`7625596970564337683`
- Content Pattern：`V04`
- Commercial Pattern：规模爆款型->高消耗低效型
- Observation：`obs_842bbed15b6e6e35d88b`

## 四、九项指标预测与实际偏差

| 指标 | 实际状态 | 幅度判断 | 方向 | 严重度 |
|---|---|---|---|---|
| daily_spend | positive | above | positive | severe |
| daily_gmv | positive | within | neutral | within |
| daily_orders | positive | within | neutral | within |
| ctr | positive | within | neutral | within |
| cvr | positive | below | negative | mild |
| settle_roi | positive | below | negative | mild |
| settle_cpo | positive | above | negative | mild |
| refund_rate | zero | not_applicable | neutral | not_applicable |
| settle_rate | positive | within | neutral | within |

## 五、Commercial Pattern五维诊断

| 维度 | 预测Level | 实际Level | Level差 | 结果 |
|---|---:|---:|---:|---|
| Attraction | 2 | 3 | 1 | within |
| Conversion | 2 | 1 | -1 | within |
| Efficiency | 5 | 2 | -3 | within |
| Scale | 3 | 4 | 1 | within |
| Quality | 3 | 5 | 2 | within |

## 六、建议与沉淀

- 建议代码：REPLICATE_SUCCESS
- 样本池动作：`add_as_positive_outlier`
- Cluster `cluster_d1c3eae7e3ff7f61`：`proposed`；有效Observation 5条
