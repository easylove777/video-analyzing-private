# 视频 Pattern 分类规则——AI执行版

- 版本：1.1.0
- 生效日期：2026-08-07
- 适用对象：AI分类器、规则引擎、数据处理程序、自动化工作流
- 适用范围：茶叶电商短视频素材；其他类目使用前必须重新校准内容标签和商业阈值
- 数据粒度：每个 `material_id` 一行
- 商业数据口径：日均数据
- 最终输出约束：每条视频输出5个五维标签、1个视频级 Content Pattern、1个 Commercial Pattern

## 1. 核心定义

### 1.1 Content Pattern

Content Pattern 描述视频主要依靠什么内容机制推动用户购买。它由五个内容维度先独立分类，再通过确定性评分合成为 V01–V10 中的唯一类别。

Content Pattern 不使用 CTR、CVR、ROI、GMV 等投放结果，不代表素材表现好坏。

### 1.2 Commercial Pattern

Commercial Pattern 描述视频投放后呈现出的商业结果形态。它由日均投放指标计算 Attraction、Conversion、Efficiency、Scale、Quality，再按固定优先级输出唯一类别。

### 1.3 概率

本文中的概率是历史样本经验占比，不是未来预测概率：

```text
P(Commercial Pattern = c | Content Pattern = v)
= 内容类别v中命中商业类别c的视频数 / 内容类别v的视频总数
```

## 2. 输入字段规范

### 2.1 内容字段

| 字段 | 类型 | 必填 | 用途 |
|---|---|---:|---|
| `material_id` | string | 是 | 唯一标识 |
| `caption` | string | 是 | 完整口播/字幕证据 |
| `first_three_seconds` | string | 否 | 开头3秒证据；缺失时从 `caption` 前部推断 |
| `core_hook` | string | 否 | 钩子语义描述；优先于 `first_three_seconds` |
| `pain_point` | string | 否 | 消费者问题/顾虑 |
| `main_selling_point` | string | 否 | 产品主要说服理由 |
| `audience_angle` | string | 否 | 目标人群及购买动机 |
| `content_form` | string | 否 | 主要表现/叙事形式 |

### 2.2 日均商业字段

| 标准含义 | 源字段 |
|---|---|
| Spend | `daily_avg_stat_cost_for_roi2` |
| 展现 | `daily_avg_product_show_count_for_roi2` |
| 点击 | `daily_avg_product_click_count_for_roi2` |
| 支付订单 | `daily_avg_total_pay_order_count_for_roi2` |
| 支付GMV | `daily_avg_total_pay_order_gmv_include_coupon_for_roi2` |
| 结算金额 | `daily_avg_total_order_settle_amount_for_roi2_1h` |
| 结算订单 | `daily_avg_total_order_settle_count_for_roi2_1h` |
| 退款订单 | `daily_avg_total_refund_order_count_for_roi2_1h` |

## 3. 通用预处理规则

1. 空白、换行和连续空格统一为单空格；首尾空白删除。
2. 同一字段出现多个信息时，优先识别开头、第一条、篇幅最长或被重复强调的主信息。
3. “顺便提到”“同时还有”“另外支持”等辅助信息不得覆盖主要表达。
4. 钩子优先读取 `core_hook`；为空时读取 `first_three_seconds`；仍为空时读取 `caption` 开头约130字。
5. 痛点、卖点、人群和形式分别独立判断，不得因为已经选中某个 V 类而反向修改五维标签。
6. 每个维度必须且只能输出一个标签。证据不足时使用该维度的明确兜底类，不允许输出数组。
7. 文本包含多个候选类别时，按“开头证据 > 明确主张 > 重复次数 > 辅助信息”的顺序裁决。

## 4. 五维 Content 标签规则

### 4.1 core_hook：靠什么把人留下来

| 编码与名称 | 必要主证据 | 排除/冲突标准 |
|---|---|---|
| H01｜低价利益型 | 开头直接给价格、优惠、赠品、份量、活动或“低门槛带走” | 价格只在结尾出现不算；开头先承诺包退则选H02 |
| H02｜零风险承诺型 | 开头以试喝、无理由退换、不好喝包退、售后兜底吸引停留 | 仅常规售后说明不算；主要讲低价则选H01 |
| H03｜产地身份背书型 | 开头突出茶农、茶厂、原产地、仓库、品牌资历或源头身份 | 只展示工厂但开头主讲口感时不选 |
| H04｜痛点共鸣型 | 开头直接说怕踩坑、买不到、不会选、担心品质等用户问题 | 若用对立、质疑、挑战制造冲突，优先H05 |
| H05｜反差冲突型 | 开头出现真假对立、行业乱象、挑战、反常识、强对比 | 普通问题描述无对立张力时选H04 |
| H06｜提问悬念型 | 开头用问题、未知答案、悬念引导继续观看 | 问题只是语气词且立即直给卖点，不选H06 |
| H07｜新品稀缺型 | 开头突出新品上市、时令、限量、库存、错过成本 | 单纯“新茶”作为产品属性但无稀缺压力不算 |
| H08｜品质口感直给型 | 开头直接给香气、口感、回甘、汤色、耐泡等结果 | 若先用真实试饮/街采结果证明，优先H10 |
| H09｜精准人群点名型 | 开头明确点名老茶客、新茶友、送礼人群等目标用户 | 点名之后更强地抛价格/风险承诺时按后者分类 |
| H10｜场景体验型 | 开头依靠开箱、试饮、街采、互动、冲泡画面或真实体验留人 | 仅静态产品展示不算，归H08或H03 |

兜底：钩子证据存在但无法归类时，优先按主表达归H08；完全无有效开头证据时标记 `CONTENT_INPUT_INSUFFICIENT`，不继续视频级分类。

### 4.2 pain_point：用户有什么问题

| 编码与名称 | 必要主证据 | 排除/冲突标准 |
|---|---|---|
| P01｜真伪产地顾虑型 | 假货、冒充、产地不明、以次充好、正宗难辨 | 主要是不会选而非真假问题时选P06 |
| P02｜口感品质不佳型 | 香气淡、苦涩、不回甘、不耐泡、碎茶、品质差 | 明确聚焦添加剂安全时选P05 |
| P03｜价格性价比顾虑型 | 价格高、溢价、买贵、预算有限、性价比低 | 主要担心买后不满意时选P04 |
| P04｜网购试错售后风险型 | 不敢下单、无法试喝、退换困难、线上踩坑、售后无保障 | 真假辨别是核心时选P01 |
| P05｜添加安全顾虑型 | 香精、色素、农残、农药、化肥、防腐剂、饮用安全 | 泛化“品质不好”但无安全词时选P02 |
| P06｜选茶困难型 | 不懂茶、不会挑、选择成本高、找不到合适产品 | 若困难专门针对送礼则选P07 |
| P07｜送礼选品困难型 | 送礼不体面、不知道送什么、包装档次、商务礼赠难选 | 仅提到可送礼但未描述选择问题，不选P07 |

兜底：无法识别明确问题时选最接近的P02；不得把产品卖点直接复制成痛点。

### 4.3 main_selling_point：产品靠什么说服用户

| 编码与名称 | 必要主证据 | 排除/冲突标准 |
|---|---|---|
| S01｜正宗源头直供型 | 原产地、茶农/茶厂直供、自有茶园、正宗身份 | 产地只是背景，主要篇幅讲工艺则选S04 |
| S02｜香气口感回甘型 | 香气、甜润、回甘、顺滑、不苦涩等饮用结果 | 主要依靠耐泡、叶底、茶汤可视证据时选S03 |
| S03｜可视品质耐泡型 | 茶干、叶底、汤色、颗粒、耐泡次数等可观察品质 | 单纯口感形容无可视证明时选S02 |
| S04｜高山原料工艺型 | 高海拔、手采、一芽多叶、传统工艺、制茶过程 | 只有产区身份无原料/工艺证明时选S01 |
| S05｜高性价比福利型 | 低价、直供价、赠品、活动、份量、优惠机制 | 只有“性价比高”一句但主要讲口感时不选 |
| S06｜无添加安全型 | 无香精、无色素、无农残、天然种植、安全饮用 | 泛化“天然好茶”无具体安全主张时不选 |
| S07｜试喝退换保障型 | 免费试喝、无理由退换、不满意包退、售后承诺 | 常规包邮不等于风险保障 |
| S08｜礼盒送礼型 | 礼盒、手提袋、独立包装、商务送礼、体面属性 | 仅包装展示但未表达礼赠价值时不选 |

兜底：无法判断时依据 `main_selling_point` 第一主张；禁止以 `content_form` 替代卖点。

### 4.4 audience_angle：在对谁说、为什么对他说

| 编码与名称 | 必要主证据 | 排除/冲突标准 |
|---|---|---|
| A01｜送礼商务·体面实用型 | 送礼、商务、待客、孝敬长辈，以体面实用为动机 | 只出现礼盒但目标是自饮，不选 |
| A02｜资深茶友·品质升级型 | 老茶客、懂茶、嘴刁，追求高品质或风味升级 | 普通喝茶人群无专业要求时选A09 |
| A03｜入门茶友·低门槛尝鲜型 | 新手、新茶友、第一次尝试，动机是低风险入门 | 主要强调价格预算时选A05 |
| A04｜日常自饮·口粮实用型 | 居家、办公、每天喝、口粮茶、长期实用 | 广泛茶友但无日常场景时选A09 |
| A05｜价格敏感·高性价比型 | 预算有限、追求便宜实惠或高性价比 | 低风险试喝是核心动机时选A03/A07 |
| A06｜健康敏感·安全饮茶型 | 关注添加、农残、天然、健康安全 | 只是追求好口感时选A09 |
| A07｜网购谨慎·避坑保障型 | 怕网购踩坑、担心售后或真假，需要保障 | 主要不会选茶但无网购风险时不选 |
| A08｜中老年茶友·传统风味型 | 明确中老年、长辈、传统茶友，追求传统风味 | “送长辈”以礼赠为主时选A01 |
| A09｜泛茶友·品质口感型 | 泛饮茶人群，主要追求品质、香气、口感 | 只有在无更具体人群动机时使用 |

兜底：A09。

### 4.5 content_form：用什么形式讲出来

| 编码与名称 | 必要主证据 | 排除/冲突标准 |
|---|---|---|
| F01｜街采互动剧情型 | 街采、路人互动、人物对话、情景剧情 | 单人面对镜头口播选F06 |
| F02｜图文漫画AI混剪型 | 图文、漫画、动画、AI生成、素材混剪为主体 | 少量B-roll辅助真人口播不选 |
| F03｜开箱测评体验型 | 开箱、测评、第一人称体验、试用反馈 | 只展示包装与产品细节选F07 |
| F04｜产地工厂仓库溯源型 | 茶园、工厂、仓库、制茶现场为主要叙事空间 | 背景偶尔出现仓库但主体是口播选F06 |
| F05｜冲泡演示品鉴型 | 冲泡、品鉴、试饮、茶汤/叶底变化为主线 | 仅短暂冲泡镜头不选 |
| F06｜真人出镜口播型 | 真人面对镜头讲解为主体 | 真人只做动作无连续讲解时选F07/F05 |
| F07｜产品细节展示型 | 产品、包装、茶干、细节特写为主体 | 有完整开箱测评过程时选F03 |
| F08｜多场景混合叙事型 | 两种以上形式权重接近，无法确认唯一主形式 | 只有辅助镜头切换不能使用F08 |

兜底：F07。

## 5. 视频级 Content Pattern 规则

### 5.1 类别定义

| 编码与名称 | 核心成交机制 |
|---|---|
| V01｜低价福利促销型 | 依靠低价、赠品、活动和份量优势降低购买门槛 |
| V02｜零风险保障转化型 | 依靠试喝、包退和售后承诺消除试错风险 |
| V03｜产地身份信任型 | 依靠茶农、茶厂、原产地和溯源场景建立信任 |
| V04｜品质口感种草型 | 依靠香气、口感、回甘、汤色和耐泡表现促成购买 |
| V05｜原料工艺价值型 | 依靠高海拔原料、手采和制茶工艺证明产品价值 |
| V06｜健康安全安心型 | 依靠无添加、无农残和天然种植等信息建立安全感 |
| V07｜礼赠场景驱动型 | 依靠送礼、商务、待客、包装和体面属性推动购买 |
| V08｜新品稀缺抢鲜型 | 依靠新品上市、时令、限量或错过成本推动即时决策 |
| V09｜痛点避坑教育型 | 先放大假货、买贵、难选等问题，再给出解决方案 |
| V10｜体验证明转化型 | 依靠开箱、街采、试饮、测评或互动反馈形成真实证明 |

#### 5.1.1 Cluster等权校准边界

- V01：Cluster等权高频证据为H01（低价利益型）、P03（价格性价比顾虑型）、S02（香气口感回甘型）；与V06冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V02：Cluster等权高频证据为H02（零风险承诺型）、A07（网购谨慎·避坑保障型）、F03（开箱测评体验型）；与V06冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V03：Cluster等权高频证据为F04（产地工厂仓库溯源型）、S01（正宗源头直供型）、P01（真伪产地顾虑型）；与V05冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V04：Cluster等权高频证据为P02（口感品质不佳型）、S02（香气口感回甘型）、F07（产品细节展示型）；与V08冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V05：Cluster等权高频证据为A02（资深茶友·品质升级型）、F04（产地工厂仓库溯源型）、S04（高山原料工艺型）；与V03冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V06：本轮无Cluster覆盖，沿用1.0.0定义、权重与排除边界。
- V07：Cluster等权高频证据为A01（送礼商务·体面实用型）、F05（冲泡演示品鉴型）、H08（品质口感直给型）；与V05冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V08：Cluster等权高频证据为H07（新品稀缺型）、P02（口感品质不佳型）、A03（入门茶友·低门槛尝鲜型）；与V05冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V09：Cluster等权高频证据为F04（产地工厂仓库溯源型）、H04（痛点共鸣型）、P03（价格性价比顾虑型）；与V05冲突时按主叙事总分、Hook映射、卖点映射依次裁决。
- V10：本轮无Cluster覆盖，沿用1.0.0定义、权重与排除边界。

### 5.2 确定性分值表

未列出的五维编码对该V类贡献0分。

| V类 | 非零证据分值 |
|---|---|
| V01 | H01=12；S05=12；P03=7；A05=6 |
| V02 | H02=12；H04=1；S02=4；S07=10；P04=9；A07=8；F03=4 |
| V03 | H03=12；S01=12；P01=9；A08=2；F04=6 |
| V04 | H05=2；H06=1；H08=12；S02=12；S03=12；P02=9；A02=5；A04=5；A09=6；F05=4；F07=4 |
| V05 | H03=4；S04=12；P01=3；A02=7；F04=6 |
| V06 | H04=2；S06=11；P05=8；A06=7 |
| V07 | H08=6；S04=6；S08=11；P07=11；A01=12；F05=6 |
| V08 | H07=12；S04=3；S05=2；P02=6；A03=6；F06=3 |
| V09 | H04=12；H05=10；P01=2；P03=5；P06=10；A07=2；F04=4 |
| V10 | H06=6；H10=12；F01=8；F02=5；F03=8；F05=3 |

计算公式：

```text
score(V) = 五个已选维度编码在V分值表中的分值之和
```

### 5.3 同分裁决

按以下顺序选择唯一结果：

1. 总分最高。
2. 若同分，选择与 `core_hook` 直接映射一致的V类。
3. 仍同分，选择与 `main_selling_point` 直接映射一致的V类。
4. 仍同分，选择编号最小的V类。

钩子直接映射：H01→V01，H02→V02，H03→V03，H04→V09，H05→V09，H06→V10，H07→V08，H08→V04，H10→V10。未列出的钩子不提供直接映射。

卖点直接映射：S01→V03，S02→V04，S03→V04，S04→V05，S05→V01，S06→V06，S07→V02，S08→V07。

## 6. Commercial 指标计算

所有输入均为日均值。

```text
CTR = 点击 / 展现
CVR = 支付订单 / 点击
结算ROI = 结算金额 / Spend
结算CPO = Spend / 结算订单
退款率 = 退款订单 / 支付订单
结算率 = 结算订单 / 支付订单
```

除零规则：分母为0时结果记0；结算订单为0时CPO记0但其反向层级必须记1；CTR、CVR、退款率、结算率计算后限制在 `[0,1]`。

## 7. 指标分层与复合维度

### 7.1 当前版本阈值

阈值来自当前275条素材正值样本的 P20/P40/P60/P80。

| 指标 | P20 | P40 | P60 | P80 | 方向 |
|---|---:|---:|---:|---:|---|
| CTR | 3.30% | 4.20% | 5.25% | 7.01% | 越高越好 |
| CVR | 2.48% | 3.36% | 4.45% | 6.78% | 越高越好 |
| 结算ROI | 1.60 | 1.91 | 2.26 | 3.34 | 越高越好 |
| 结算CPO | 41.24 | 62.12 | 81.51 | 134.60 | 越低越好 |
| 日均Spend | 0.42 | 1.15 | 3.04 | 16.19 | 越高代表规模越大 |
| 日均GMV | 10.64 | 21.65 | 57.49 | 199.28 | 越高代表规模越大 |
| 日均订单 | 0.07 | 0.14 | 0.30 | 1.05 | 越高代表规模越大 |

正向指标层级：0或无效=1；`(0,P20]`=1；`(P20,P40]`=2；`(P40,P60]`=3；`(P60,P80]`=4；`>P80`=5。

CPO反向层级：无结算订单=1；`(0,P20]`=5；`(P20,P40]`=4；`(P40,P60]`=3；`(P60,P80]`=2；`>P80`=1。

### 7.2 五个商业维度

```text
AttractionLevel = CTR层级
ConversionLevel = CVR层级
EfficiencyScore = 0.70 × ROILevel + 0.30 × CPOLevel
ScaleScore = 0.40 × SpendLevel + 0.35 × GMVLevel + 0.25 × OrderLevel
QualityScore = 0.60 × 结算率 + 0.40 × (1 - 退款率)
```

Efficiency/Scale得分转层级：`<1.5`=1；`[1.5,2.5)`=2；`[2.5,3.5)`=3；`[3.5,4.5)`=4；`≥4.5`=5。

若结算订单=0，EfficiencyScore和EfficiencyLevel均强制为1。

Quality层级：支付订单=0时为0（未知）；否则 `<0.2`=1，`[0.2,0.4)`=2，`[0.4,0.6)`=3，`[0.6,0.8)`=4，`≥0.8`=5。

## 8. Commercial Pattern 优先级规则

必须从上到下判断，命中后立即停止。

| 优先级 | 类别 | 完整布尔规则 |
|---:|---|---|
| 1 | 待验证型 | `SpendLevel=1 AND 日均订单=0 AND 日均GMV=0` |
| 2 | 规模爆款型 | `EfficiencyLevel>=4 AND ScaleLevel>=4 AND QualityLevel>=3` |
| 3 | 高效潜力型 | `EfficiencyLevel>=4 AND ScaleLevel<=3` |
| 4 | 强引流型 | `AttractionLevel>=4 AND ConversionLevel<=2 AND EfficiencyLevel<=3` |
| 5 | 强转化型 | `ConversionLevel>=4 AND AttractionLevel<=3 AND EfficiencyLevel>=3` |
| 6 | 稳定经营型 | `EfficiencyLevel>=3 AND ScaleLevel>=3 AND AttractionLevel>=3 AND ConversionLevel>=3` |
| 7 | 高消耗低效型 | `SpendLevel>=4 AND EfficiencyLevel<=2` |
| 8 | 低效型 | `EfficiencyLevel<=2 AND ScaleLevel<=3 AND AttractionLevel<=3 AND ConversionLevel<=3` |
| 9 | 普通型 | 未命中1–8 |

“待验证型”仅是日均代理：当前没有统计天数、累计消耗和累计订单，禁止将其解释为真实投放周期短。

## 9. 概率汇总规则

### 9.1 Content Pattern 自身分布

五维标签和视频级V类分别统计数量与占比：

```text
dimension_count[d][k] = count(有效内容记录中 dimension=d 且 label=k)
dimension_share[d][k] = dimension_count[d][k] / valid_content_record_count
video_pattern_count[v] = count(有效内容记录中 content_pattern=v)
video_pattern_share[v] = video_pattern_count[v] / valid_content_record_count
```

统计要求：

- 分母只包含成功得到H/P/S/A/F和V类的有效内容记录；被拒绝记录单独输出，不得混入分母。
- 每个内容维度的全部标签数量之和必须等于有效内容记录数，占比之和必须等于1。
- V01–V10数量之和必须等于有效内容记录数，占比之和必须等于1。
- 输出数量、占比、有效分母和拒绝数量；不得只输出百分比。

### 9.2 Content Pattern 内的 Commercial Pattern 概率

对每个 V01–V10 分别统计九类 Commercial Pattern：

```text
probability[v][c] = count(video_content_pattern=v AND commercial_pattern=c)
                    / count(video_content_pattern=v)
```

约束：

- 每个有样本的V类，九个概率之和必须等于1，允许浮点误差 `±0.000001`。
- 同时输出分子、分母和概率，禁止只输出百分比。
- `n<20` 必须增加 `small_sample_warning=true`。
- `n=0` 时概率返回 `null`，不得返回0或100%。

## 10. 缺失值与异常处理

| 情况 | 处理 |
|---|---|
| `material_id` 缺失/重复 | 拒绝该记录并输出错误 |
| `caption` 为空 | 拒绝内容分类 |
| 某内容字段为空 | 使用相邻证据字段回退；五维仍无法判断则报输入不足 |
| 商业数值为空、非数值或负数 | 标记 `COMMERCIAL_INPUT_INVALID`，不分类 |
| 展现/点击/订单分母为0 | 对应比率记0 |
| 计算比率大于1 | 截断为1，并记录 `RATE_CLIPPED` |
| 支付订单为0 | QualityLevel=0 |
| 结算订单为0 | CPOLevel=1，EfficiencyLevel=1 |
| 内容V类样本数小于20 | 输出小样本警告 |
| 同一条视频命中多个商业规则 | 按优先级保留第一个，禁止多标签 |

## 11. 确定性伪代码

```text
function classifyVideo(row):
    validateMaterialIdAndCaption(row)
    H = classifyHook(row.core_hook, row.first_three_seconds, row.caption)
    P = classifyPain(row.pain_point, row.caption)
    S = classifySelling(row.main_selling_point, row.caption)
    A = classifyAudience(row.audience_angle, row.caption)
    F = classifyForm(row.content_form, row.caption)

    for V in [V01..V10]:
        V.score = weight[V][H] + weight[V][P] + weight[V][S] + weight[V][A] + weight[V][F]
    contentPattern = argmax(V.score, tieByHook, tieBySelling, smallestVCode)

    metrics = calculateDailyMetrics(row)
    levels = calculateLevels(metrics, thresholds)
    commercialPattern = firstMatch(levels, orderedCommercialRules)

    return {H, P, S, A, F, contentPattern, metrics, levels, commercialPattern}
```

## 12. JSON 输入输出规范

### 12.1 输入示例

```json
{
  "material_id": "7042493287601946628",
  "caption": "……",
  "first_three_seconds": "……",
  "core_hook": "……",
  "pain_point": "……",
  "main_selling_point": "……",
  "audience_angle": "……",
  "content_form": "……",
  "daily": {
    "spend": 125.5,
    "shows": 3200,
    "clicks": 180,
    "pay_orders": 8,
    "pay_gmv": 760,
    "settle_amount": 520,
    "settle_orders": 6,
    "refund_orders": 1
  }
}
```

### 12.2 单条输出示例

```json
{
  "material_id": "7042493287601946628",
  "content_dimensions": {
    "core_hook": "H02｜零风险承诺型",
    "pain_point": "P02｜口感品质不佳型",
    "main_selling_point": "S01｜正宗源头直供型",
    "audience_angle": "A04｜日常自饮·口粮实用型",
    "content_form": "F07｜产品细节展示型"
  },
  "content_pattern": "V04｜品质口感种草型",
  "content_pattern_score": 12,
  "commercial_metrics": {
    "ctr": 0.05625,
    "cvr": 0.04444,
    "settle_roi": 4.14343,
    "settle_cpo": 20.91667,
    "refund_rate": 0.125,
    "settle_rate": 0.75
  },
  "commercial_levels": {
    "attraction": 4,
    "conversion": 3,
    "efficiency": 5,
    "scale": 5,
    "quality": 5
  },
  "commercial_pattern": "规模爆款型",
  "warnings": []
}
```

### 12.3 概率输出示例

```json
{
  "content_pattern": "V03｜产地身份信任型",
  "sample_size": 102,
  "small_sample_warning": false,
  "commercial_pattern_distribution": {
    "待验证型": {"count": 29, "probability": 0.284314},
    "规模爆款型": {"count": 2, "probability": 0.019608}
  }
}
```

## 13. 机器验收规则

1. 输入记录数等于输出记录数加拒绝记录数。
2. 每条有效视频恰好有H、P、S、A、F各一个标签。
3. 每条有效视频恰好有一个V类和一个Commercial Pattern。
4. 所有V类必须属于V01–V10；所有商业类必须属于九类白名单。
5. 商业指标不得出现 `NaN`、无穷值或负值。
6. 率指标必须位于 `[0,1]`。
7. EfficiencyLevel和ScaleLevel必须位于1–5；QualityLevel必须位于0–5。
8. 每个内容类的商业概率和必须为1或在样本数为0时全部为 `null`。
9. 同一输入重复执行必须得到完全相同的输出。
10. 阈值、分值表或优先级发生变化时必须升级版本号并同步人工操作版。

## 14. 版本变更规则

- 修改类别名称、类别含义、V分值、商业阈值、复合权重或优先级均属于破坏性变更，升级主版本或次版本。
- 只修改示例、错别字或解释，不改变结果时升级修订号。
- AI执行版与人工操作版必须在同一提交中同步更新。
